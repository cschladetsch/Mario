﻿namespace Liquid
{
    internal class Material
    {
        public float m;
        public float rd;
        public float k;
        public float v;
        public float d;
        public float g;

        public Material(float m, float rd, float k, float v, float d, float g)
        {
            this.m = m;
            this.rd = rd;
            this.k = k;
            this.v = v;
            this.d = d;
            this.g = g;
        }
    }


}

//EOF
