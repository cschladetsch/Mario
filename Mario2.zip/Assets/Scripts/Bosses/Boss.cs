﻿/// <summary>
/// Base class for all Boss objects in the game
/// </summary>
public class Boss : MarioObject
{
}
