﻿using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

public enum IngredientType
{
	Cherry,
	Muffin,
	CupCake,

	Chocolate,
	Mint,
	MintIceCream,

	None,

}
