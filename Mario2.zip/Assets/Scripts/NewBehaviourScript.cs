﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
	
	void Awake()
	{
	}

	void Start()
	{
	}

	void Update()
	{
	}
}


