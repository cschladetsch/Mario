﻿namespace LiquidSim
{
    internal class Node
    {
        public float m;
        public float d;
        public float gx;
        public float gy;
        public float u;
        public float v;
        public float ax;
        public float ay;
        public bool active;
    }
}

//EOF
