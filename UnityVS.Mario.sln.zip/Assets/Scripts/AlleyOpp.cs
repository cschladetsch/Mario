﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class AlleyOpp : MonoBehaviour
{
	
	void Awake()
	{
	}

	void Start()
	{
	}

	void Update()
	{
	}
}


