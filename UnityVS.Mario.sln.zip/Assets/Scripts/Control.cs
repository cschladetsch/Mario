﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class Control : MonoBehaviour
{

	void Awake()
	{
	}

	void Start()
	{
	}

	void Update()
	{
	}
}
