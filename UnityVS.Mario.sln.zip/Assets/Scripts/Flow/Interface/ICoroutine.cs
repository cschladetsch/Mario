//

namespace Flow
{
	public interface ICoroutine : IGenerator
	{
	}
}