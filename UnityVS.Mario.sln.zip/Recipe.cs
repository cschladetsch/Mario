﻿using System.Collections.Generic;

public class Recipe
{
	public List<Ingredient> Ingredients = new List<Ingredient>();
	public float CookingTime;
}